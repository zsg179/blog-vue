import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: () => import('@/views/index'),
      meta:{
        title: '拾忆往昔的个人博客网站'
      }
    },
    {
      path: '/blog/:blogId',
      name: 'BlogDetail',
      component: () => import('@/views/BlogDetail'),
      meta:{
        title: '拾忆往昔的个人博客网站'
      }
    }
  ]
})
