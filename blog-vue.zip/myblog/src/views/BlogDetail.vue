<template>
    <div>
        BlogDetail....
    </div>
</template>