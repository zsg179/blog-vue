<template>
    <div class="footer">
      <p>Copyright © 2020</p>
      <p>www.pekka.icu All rights reserved. 桂ICP备20005308号-2</p>
    </div>
</template>

<style scoped>
.footer {
  height: 50px;
  text-align: center;
  margin-top: 50px;
  color: #737373;
  font:12px/1.5 Microsoft YaHei,Heiti SC,tahoma,arial,Hiragino Sans GB,"\5B8B\4F53",sans-serif
}

</style>